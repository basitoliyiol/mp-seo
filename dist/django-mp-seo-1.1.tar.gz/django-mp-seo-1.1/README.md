# mp-seo
Django seo app
